import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ManageRestaurantsComponent } from './components/manage-restaurants/manage-restaurants.component';
import { ManageUsersComponent } from './components/manage-users/manage-users.component';
import { ManageOrdersComponent  } from './components/manage-orders/manage-orders.component';
import { ManageRatingsComponent } from './components/manage-ratings/manage-ratings.component';

 const routes: Routes = [

  { path: 'restaurants', component: ManageRestaurantsComponent },
  { path: 'users', component: ManageUsersComponent },
  { path: 'orders', component: ManageOrdersComponent },
  { path: 'ratings', component: ManageRatingsComponent } 
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
