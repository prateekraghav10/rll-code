import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';

interface Rating {
  _id?: string;
  user: { name: string };
  restaurant: { name: string };
  rating: number;
}

@Component({
  selector: 'app-manage-ratings',
  templateUrl: './manage-ratings.component.html',
  styleUrls: ['./manage-ratings.component.css']
})
export class ManageRatingsComponent implements OnInit {
  ratings: Rating[] = [];

  constructor(private apiService: ApiService) {}

  ngOnInit() {
    this.fetchRatings();
  }

  fetchRatings() {
    this.apiService.getRatings().subscribe(
      (data) => this.ratings = data,
      (error) => console.error('Error fetching ratings:', error)
    );
  }

  updateRating(ratingId: string, newRating: number) {
    this.apiService.updateRating(ratingId, { rating: newRating }).subscribe(
      () => this.fetchRatings(),
      (error) => console.error('Error updating rating:', error)
    );
  }

  deleteRating(ratingId: string) {
    this.apiService.deleteRating(ratingId).subscribe(
      () => this.fetchRatings(),
      (error) => console.error('Error deleting rating:', error)
    );
  }
}
