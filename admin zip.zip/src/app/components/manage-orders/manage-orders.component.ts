import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';
interface Order {
  _id?: string; // ✅ Change `_id` to optional (fixing the undefined issue)
  user: { name: string; email: string };
  restaurant: { name: string };
  totalAmount: number;
  status: string;
}

interface GroupedUserOrders {
  name: string;
  email: string;
  orders: Order[];
}

@Component({
  selector: 'app-manage-orders',
  templateUrl: './manage-orders.component.html',
  styleUrls: ['./manage-orders.component.css']
})
export class ManageOrdersComponent implements OnInit {
  orders: Order[] = [];
  groupedOrders: GroupedUserOrders[] = [];
  showUserOrders = false;
  selectedUser: GroupedUserOrders | null = null;

  constructor(private apiService: ApiService) {}

  ngOnInit(): void {
    this.getOrders();
  }

 getOrders(): void {
  this.apiService.getOrders().subscribe({
    next: (data: Order[]) => {
      // ✅ Ensures `_id` always exists before assigning
      this.orders = data.map(order => ({
        ...order,
        _id: order._id ?? 'unknown' // Defaults to 'unknown' if `_id` is undefined
      }));
      this.groupOrdersByUser();
    },
    error: (err: any) => console.error('Error fetching orders:', err)
  });
}


  groupOrdersByUser(): void {
    const userMap = new Map<string, GroupedUserOrders>();

    for (const order of this.orders) {
      const { email, name } = order.user;
      if (!userMap.has(email)) {
        userMap.set(email, { name, email, orders: [] });
      }
      userMap.get(email)!.orders.push(order);
    }

    this.groupedOrders = Array.from(userMap.values());
  }

  viewUserOrders(user: GroupedUserOrders): void {
    this.selectedUser = user;
    this.showUserOrders = true;
  }

  closeUserOrders(): void {
    this.selectedUser = null;
    this.showUserOrders = false;
  }

  deleteOrder(id: string): void {
    if (!id) {
      console.error("Error: Cannot delete order with undefined ID");
      return;
    }
    this.apiService.deleteOrder(id).subscribe({
      next: () => this.getOrders(),
      error: (err) => console.error('Error deleting order:', err)
    });
  }
}
