import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';

interface Restaurant {
  _id?: string;
  name: string;
  location: string;
  cuisine: string;
  rating: number;
}

@Component({
  selector: 'app-manage-restaurants',
  templateUrl: './manage-restaurants.component.html',
  styleUrls: ['./manage-restaurants.component.css']
})
export class ManageRestaurantsComponent implements OnInit {
  restaurants: Restaurant[] = [];
  showForm = false;
  editing = false;
  restaurantData: Restaurant = { name: '', location: '', cuisine: '', rating: 0 };

  constructor(private apiService: ApiService) {}

  ngOnInit() {
    this.getRestaurants();
  }

  getRestaurants() {
    this.apiService.getRestaurants().subscribe({
      next: (data: Restaurant[]) => {
        this.restaurants = data;
        console.log('Fetched restaurants:', this.restaurants);
      },
      error: (err) => console.error('Error fetching restaurants:', err)
    });
  }

  openAddForm() {
    this.showForm = true;
    this.editing = false;
    this.restaurantData = { name: '', location: '', cuisine: '', rating: 0 };
  }

  editRestaurant(restaurant: Restaurant) {
    this.showForm = true;
    this.editing = true;
    this.restaurantData = { ...restaurant };
  }

  saveRestaurant() {
    console.log('Saving restaurant:', this.restaurantData);

    if (!this.restaurantData.name || !this.restaurantData.location || !this.restaurantData.cuisine) {
      console.error('Error: Missing required fields');
      alert('Please fill in all fields.');
      return;
    }

    const request$ = this.editing && this.restaurantData._id
      ? this.apiService.updateRestaurant(this.restaurantData._id, this.restaurantData)
      : this.apiService.addRestaurant(this.restaurantData);

    request$.subscribe({
      next: (response) => {
        console.log('Save successful:', response);
        this.getRestaurants();
        this.closeForm();
      },
      error: (err) => {
        console.error('Error saving restaurant:', err);
        alert('Failed to save restaurant. Please check console for details.');
      }
    });
  }

  deleteRestaurant(id?: string) {
    if (!id) {
      console.error('Error: Cannot delete restaurant without an ID');
      return;
    }

    console.log('Deleting restaurant ID:', id);

    this.apiService.deleteRestaurant(id).subscribe({
      next: () => {
        console.log('Delete successful');
        this.getRestaurants();
      },
      error: (err) => {
        console.error('Error deleting restaurant:', err);
        alert('Failed to delete restaurant.');
      }
    });
  }

  closeForm() {
    this.showForm = false;
  }
}

