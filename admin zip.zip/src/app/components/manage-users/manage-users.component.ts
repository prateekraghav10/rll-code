import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../services/api.service';

interface User {
  _id?: string;
  name: string;
  email: string;
  role: string;
}

@Component({
  selector: 'app-manage-users',
  templateUrl: './manage-users.component.html',
  styleUrls: ['./manage-users.component.css']
})
export class ManageUsersComponent implements OnInit {
  users: User[] = [];
  showForm = false;
  editing = false;
  userData: User = { name: '', email: '', role: 'user' };
  successMessage = '';
  errorMessage = '';

  constructor(private apiService: ApiService) {}

  ngOnInit() {
    this.getUsers();
  }

  /** ✅ Fetch Users */
  getUsers() {
    this.apiService.getUsers().subscribe({
      next: (data) => this.users = data,
      error: () => this.errorMessage = 'Failed to load users!'
    });
  }

  /** ✅ Open Form */
  openAddForm() {
    this.showForm = true;
    this.editing = false;
    this.userData = { name: '', email: '', role: 'user' };
  }

  /** ✅ Edit User */
  editUser(user: User) {
    this.showForm = true;
    this.editing = true;
    this.userData = { ...user };
  }

  /** ✅ Save User */
  saveUser() {
    if (!this.userData.name || !this.userData.email) {
      this.errorMessage = 'Name and Email are required!';
      return;
    }

    const request = this.editing ? this.apiService.updateUser(this.userData._id!, this.userData) : this.apiService.addUser(this.userData);
    
    request.subscribe({
      next: () => {
        this.getUsers();
        this.closeForm();
        this.successMessage = this.editing ? 'User updated!' : 'User added!';
      },
      error: () => this.errorMessage = 'Failed to save user!'
    });
  }

  /** ✅ Delete User */
  deleteUser(id?: string) {
    if (!id) return;

    this.apiService.deleteUser(id).subscribe({
      next: () => this.getUsers(),
      error: () => this.errorMessage = 'Failed to delete user!'
    });
  }

  /** ✅ Close Form */
  closeForm() {
    this.showForm = false;
    this.successMessage = '';
    this.errorMessage = '';
  }
}
