import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'Food Delivery Admin';

  constructor(private router: Router) {}

  logout() {
    // Clear admin session (You can extend this with authentication logic)
    localStorage.removeItem('adminToken');

    // Redirect to login page
    this.router.navigate(['/login']);
  }
}
