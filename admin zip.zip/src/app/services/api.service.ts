import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';

// User Interface
interface User {
  _id?: string;
  name: string;
  email: string;
  role: string;
}

// Restaurant Interface
interface Restaurant {
  _id?: string;
  name: string;
  location: string;
  cuisine: string;
  rating: number;
}

// Order Interface
interface Order {
  _id?: string;
  user: { name: string; email: string };
  restaurant: { name: string };
  items: { name: string; quantity: number; price: number }[];
  totalAmount: number;
  status: string;
}

// Rating Interface
interface Rating {
  _id?: string;
  user: { name: string };
  restaurant: { name: string };
  rating: number;
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private apiUrl = 'http://localhost:5000'; // Backend URL

  constructor(private http: HttpClient) {}

  // ** Error Handling Function **
  private handleError(error: HttpErrorResponse) {
    console.error('API Error:', error);
    return throwError(() => new Error(error.message || 'Server error'));
  }

  // ** Users API Calls **
  getUsers(): Observable<User[]> {
    return this.http.get<User[]>(`${this.apiUrl}/users`).pipe(catchError(this.handleError));
  }

  addUser(data: User): Observable<User> {
    return this.http.post<User>(`${this.apiUrl}/users`, data).pipe(catchError(this.handleError));
  }

  updateUser(id: string, data: User): Observable<User> {
    return this.http.put<User>(`${this.apiUrl}/users/${id}`, data).pipe(catchError(this.handleError));
  }

  deleteUser(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/users/${id}`).pipe(catchError(this.handleError));
  }

  // ** Restaurants API Calls **
  getRestaurants(): Observable<Restaurant[]> {
    return this.http.get<Restaurant[]>(`${this.apiUrl}/restaurants`).pipe(catchError(this.handleError));
  }

  addRestaurant(data: Restaurant): Observable<Restaurant> {
    console.log('Adding restaurant:', data);
    return this.http.post<Restaurant>(`${this.apiUrl}/restaurants`, data).pipe(catchError(this.handleError));
  }

  updateRestaurant(id: string, data: Restaurant): Observable<Restaurant> {
    console.log('Updating restaurant:', data);
    return this.http.put<Restaurant>(`${this.apiUrl}/restaurants/${id}`, data).pipe(catchError(this.handleError));
  }

  deleteRestaurant(id: string): Observable<void> {
    console.log('Deleting restaurant ID:', id);
    return this.http.delete<void>(`${this.apiUrl}/restaurants/${id}`).pipe(catchError(this.handleError));
  }

  // ** Orders API Calls **
  getOrders(): Observable<Order[]> {
    return this.http.get<Order[]>(`${this.apiUrl}/orders`).pipe(catchError(this.handleError));
  }

  getOrderById(id: string): Observable<Order> {
    return this.http.get<Order>(`${this.apiUrl}/orders/${id}`).pipe(catchError(this.handleError));
  }

  createOrder(order: Order): Observable<Order> {
    return this.http.post<Order>(`${this.apiUrl}/orders`, order).pipe(catchError(this.handleError));
  }

  updateOrder(id: string, data: Partial<Order>): Observable<Order> {
    return this.http.put<Order>(`${this.apiUrl}/orders/${id}`, data).pipe(catchError(this.handleError));
  }

  deleteOrder(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/orders/${id}`).pipe(catchError(this.handleError));
  }

  // ** Ratings API Calls **
  getRatings(): Observable<Rating[]> {
    return this.http.get<Rating[]>(`${this.apiUrl}/ratings`).pipe(catchError(this.handleError));
  }

  updateRating(id: string, data: Partial<Rating>): Observable<Rating> {
    return this.http.put<Rating>(`${this.apiUrl}/ratings/${id}`, data).pipe(catchError(this.handleError));
  }

  deleteRating(id: string): Observable<void> {
    return this.http.delete<void>(`${this.apiUrl}/ratings/${id}`).pipe(catchError(this.handleError));
  }
}
