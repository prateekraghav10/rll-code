import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';

@Component({
  selector: 'app-payment-success',
  templateUrl: './payment-success.component.html',
  styleUrls: ['./payment-success.component.css']
})
export class PaymentSuccessComponent {
  cardNumber: string = '';
  expiry: string = '';
  cvv: string = '';
  paymentComplete: boolean = false; // 🔁 Controls success message display

  constructor(private router: Router) {}

  processPayment(form: NgForm) {
    if (form.valid) {
      alert('Processing payment... 🚀');
     
        this.paymentComplete = true; // ✅ Show success UI
  
    } else {
      alert('❌ Please enter valid payment details.');
    }
  }

  cancelPayment() {
    this.cardNumber = '';
    this.expiry = '';
    this.cvv = '';
    alert('Payment has been canceled.');
  }

  redirectToThankYou() {
    this.router.navigate(['/thank-you']); // ✅ Redirect on "Continue"
  }
}
