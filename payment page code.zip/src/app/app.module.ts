import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { AppComponent } from './app.component';
import { PaymentSuccessComponent } from './payment-success/payment-success.component';
import { ThankYouComponent } from './thank-you/thank-you.component';

const routes: Routes = [
  { path: '', component: PaymentSuccessComponent },
  { path: 'thank-you', component: ThankYouComponent }
];

@NgModule({
  declarations: [
    AppComponent,
    PaymentSuccessComponent,
    ThankYouComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    RouterModule.forRoot(routes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
