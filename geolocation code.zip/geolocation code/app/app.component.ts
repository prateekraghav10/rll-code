import { Component, AfterViewInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import * as L from 'leaflet';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements AfterViewInit {
  latitude: number = 0;
  longitude: number = 0;
  city: string = 'Unknown';
  area: string = 'Unknown';
  street: string = 'Unknown';
  pincode: string = 'Unknown';
  searchedLat: number = 0;
  searchedLon: number = 0;
  searchedCity: string = 'Unknown';
  searchedArea: string = 'Unknown';
  searchedStreet: string = 'Unknown';
  searchedPincode: string = 'Unknown';
  distance: number = 0;
  map: any;
  userMarker: any;
  searchMarker: any;

  constructor(private http: HttpClient) {}

  ngAfterViewInit(): void {
    this.map = L.map('map', {
      center: [20, 78], // Default view (India)
      zoom: 5,
      zoomControl: false
    });

    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '&copy; OpenStreetMap contributors',
      maxZoom: 18
    }).addTo(this.map);

    L.control.zoom({ position: 'topright' }).addTo(this.map);

    setTimeout(() => {
      this.map.invalidateSize();
    }, 500);
  }

  getLocation() {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(position => {
        this.latitude = position.coords.latitude ?? 0;
        this.longitude = position.coords.longitude ?? 0;

        this.http.get<any>(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${this.latitude}&lon=${this.longitude}`)
          .subscribe(response => {
            this.city = response.address.city || response.address.town || response.address.village || 'Unknown';
            this.area = response.address.suburb || response.address.neighbourhood || 'Unknown';
            this.street = response.address.road || 'Unknown';
            this.pincode = response.address.postcode || 'Unknown';
          });

        this.map.setView([this.latitude, this.longitude], 12);

        if (this.userMarker) {
          this.map.removeLayer(this.userMarker);
        }

        this.userMarker = L.marker([this.latitude, this.longitude], { icon: L.icon({ iconUrl: 'https://maps.google.com/mapfiles/ms/icons/blue-dot.png' }) })
          .addTo(this.map)
          .bindPopup(`You are here: ${this.city}, ${this.area}, ${this.street}, ${this.pincode}`)
          .openPopup();
      });
    }
  }

  searchLocation(location: string) {
    if (!location.trim()) return;

    this.http.get<any>(`https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(location)}`)
      .subscribe(response => {
        console.log('Search Response:', response);

        if (response.length > 0 && response[0].lat && response[0].lon) {
          this.searchedLat = parseFloat(response[0].lat);
          this.searchedLon = parseFloat(response[0].lon);

          this.http.get<any>(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${this.searchedLat}&lon=${this.searchedLon}`)
            .subscribe(res => {
              this.searchedCity = res.address.city || res.address.town || res.address.village || 'Unknown';
              this.searchedArea = res.address.suburb || res.address.neighbourhood || 'Unknown';
              this.searchedStreet = res.address.road || 'Unknown';
              this.searchedPincode = res.address.postcode || 'Unknown';
            });

          this.map.setView([this.searchedLat, this.searchedLon], 12);

          if (this.searchMarker) {
            this.map.removeLayer(this.searchMarker);
          }

          this.searchMarker = L.marker([this.searchedLat, this.searchedLon], { 
            icon: L.icon({ iconUrl: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png' }) 
          })
          .addTo(this.map)
          .bindPopup(`Searched Location: ${location}`)
          .openPopup();

          this.calculateDistance();
        } else {
          alert('Location not found, please try again.');
        }
      }, error => {
        console.error('Search API Error:', error);
        alert('Error fetching location. Please try again later.');
      });
  }

  calculateDistance() {
    if (this.latitude && this.longitude && this.searchedLat && this.searchedLon) {
      const userLatLng = L.latLng(this.latitude, this.longitude);
      const searchedLatLng = L.latLng(this.searchedLat, this.searchedLon);
      this.distance = userLatLng.distanceTo(searchedLatLng) / 1000;
      console.log(`Distance Calculated: ${this.distance.toFixed(2)} km`);
    } else {
      console.warn('Invalid coordinates for distance calculation.');
    }
  }
}
